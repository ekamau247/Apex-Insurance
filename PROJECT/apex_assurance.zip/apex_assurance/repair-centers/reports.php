<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Ensure the user is logged in
require_login();

// Only for repair centers
require_role('RepairCenter');

$repair_center_id = $_SESSION['user_id'];

// Get date range from query parameters
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Get repair center performance statistics
$stats = [
    'total_claims' => 0,
    'completed_repairs' => 0,
    'total_revenue' => 0,
    'avg_completion_time' => 0,
    'customer_satisfaction' => 0
];

// Total claims in period
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM accident_report WHERE assigned_repair_center = ? AND assigned_repair_at BETWEEN ? AND ?");
$stmt->bind_param("iss", $repair_center_id, $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $stats['total_claims'] = $row['count'];
}

// Completed repairs and revenue
$stmt = $conn->prepare("SELECT COUNT(*) as count, SUM(re.total_cost) as revenue 
                        FROM repair_tracking rt 
                        JOIN repair_estimates re ON rt.claim_id = re.claim_id 
                        WHERE rt.repair_center_id = ? AND rt.status = 'Completed' 
                        AND rt.updated_at BETWEEN ? AND ?");
$stmt->bind_param("iss", $repair_center_id, $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $stats['completed_repairs'] = $row['count'] ?: 0;
    $stats['total_revenue'] = $row['revenue'] ?: 0;
}

// Get monthly repair trends
$monthly_data = [];
for ($i = 11; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $month_start = $month . '-01';
    $month_end = date('Y-m-t', strtotime($month_start));
    
    $stmt = $conn->prepare("SELECT COUNT(*) as repairs, SUM(re.total_cost) as revenue 
                           FROM repair_tracking rt 
                           LEFT JOIN repair_estimates re ON rt.claim_id = re.claim_id 
                           WHERE rt.repair_center_id = ? AND rt.status = 'Completed' 
                           AND rt.updated_at BETWEEN ? AND ?");
    $stmt->bind_param("iss", $repair_center_id, $month_start, $month_end);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    
    $monthly_data[] = [
        'month' => date('M Y', strtotime($month_start)),
        'repairs' => $data['repairs'] ?: 0,
        'revenue' => $data['revenue'] ?: 0
    ];
}

// Get repair status distribution
$status_distribution = [];
$result = $conn->query("SELECT rt.status, COUNT(*) as count 
                       FROM repair_tracking rt 
                       WHERE rt.repair_center_id = $repair_center_id 
                       GROUP BY rt.status");
while ($row = $result->fetch_assoc()) {
    $status_distribution[] = $row;
}

// Get top customers by repair volume
$top_customers = $conn->query("SELECT u.first_name, u.last_name, COUNT(*) as repair_count, SUM(re.total_cost) as total_spent
                              FROM accident_report ar
                              JOIN user u ON ar.user_id = u.Id
                              LEFT JOIN repair_estimates re ON ar.Id = re.claim_id AND re.repair_center_id = $repair_center_id
                              WHERE ar.assigned_repair_center = $repair_center_id
                              GROUP BY u.Id
                              ORDER BY repair_count DESC
                              LIMIT 10");

// Get recent completed repairs
$recent_repairs = $conn->query("SELECT ar.accident_report_number, u.first_name, u.last_name, c.make, c.model, 
                               re.total_cost, rt.updated_at
                               FROM repair_tracking rt
                               JOIN accident_report ar ON rt.claim_id = ar.Id
                               JOIN user u ON ar.user_id = u.Id
                               JOIN car c ON ar.car_id = c.Id
                               LEFT JOIN repair_estimates re ON ar.Id = re.claim_id AND re.repair_center_id = $repair_center_id
                               WHERE rt.repair_center_id = $repair_center_id AND rt.status = 'Completed'
                               ORDER BY rt.updated_at DESC
                               LIMIT 10");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performance Reports - Repair Center - Apex Assurance</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        :root {
            --primary-color: #0056b3;
            --repair-color: #fd7e14;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #17a2b8;
        }
        
        body {
            line-height: 1.6;
            background-color: #f8f9fa;
            color: #333;
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        /* Date Filter */
        .date-filter {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .filter-form {
            display: flex;
            gap: 15px;
            align-items: flex-end;
        }
        
        .filter-group {
            flex: 1;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .filter-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            padding: 25px;
            display: flex;
            align-items: center;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 1.2rem;
            color: white;
        }
        
        .stat-icon.repair { background-color: var(--repair-color); }
        .stat-icon.success { background-color: var(--success-color); }
        .stat-icon.info { background-color: var(--info-color); }
        .stat-icon.warning { background-color: var(--warning-color); }
        
        .stat-details h3 {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .stat-details p {
            color: #777;
            font-size: 0.8rem;
        }
        
        /* Charts Grid */
        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .chart-card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            padding: 25px;
        }
        
        .chart-header {
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .chart-header h3 {
            color: var(--repair-color);
            margin-bottom: 5px;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
        }
        
        /* Tables */
        .reports-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        
        .report-card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            padding: 25px;
        }
        
        .report-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .report-header h3 {
            color: var(--repair-color);
            margin: 0;
        }
        
        .report-header i {
            margin-right: 8px;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .report-table th,
        .report-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .report-table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: #555;
            font-size: 0.9rem;
        }
        
        .report-table td {
            font-size: 0.9rem;
        }
        
        .report-table tr:hover {
            background-color: rgba(253, 126, 20, 0.02);
        }
        
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background-color: var(--repair-color);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .btn:hover {
            background-color: #e8650e;
        }
        
        .export-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .btn-outline {
            background-color: transparent;
            border: 1px solid var(--repair-color);
            color: var(--repair-color);
        }
        
        .btn-outline:hover {
            background-color: var(--repair-color);
            color: white;
        }
        
        /* Responsive */
        @media (max-width: 991px) {
            .main-content {
                margin-left: 70px;
            }
            
            .charts-grid,
            .reports-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .filter-form {
                flex-direction: column;
            }
            
            .stats-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <div class="content-header">
                <div class="content-title">
                    <h1>Performance Reports</h1>
                    <p>Analyze your repair center's performance and trends</p>
                </div>
            </div>

            <!-- Date Filter -->
            <div class="date-filter">
                <form class="filter-form" method="GET">
                    <div class="filter-group">
                        <label for="start_date">Start Date</label>
                        <input type="date" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
                    </div>
                    <div class="filter-group">
                        <label for="end_date">End Date</label>
                        <input type="date" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn">Apply Filter</button>
                    </div>
                </form>
            </div>

            <!-- Export Buttons -->
            <div class="export-buttons">
                <button onclick="window.print()" class="btn btn-outline">
                    <i class="fas fa-print"></i> Print Report
                </button>
                <button onclick="exportToPDF()" class="btn btn-outline">
                    <i class="fas fa-file-pdf"></i> Export PDF
                </button>
            </div>

            <!-- Performance Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon repair">
                        <i class="fas fa-clipboard-list"></i>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo number_format($stats['total_claims']); ?></h3>
                        <p>Total Claims</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon success">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo number_format($stats['completed_repairs']); ?></h3>
                        <p>Completed Repairs</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon info">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo format_currency($stats['total_revenue']); ?></h3>
                        <p>Total Revenue</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon warning">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $stats['avg_completion_time']; ?> days</h3>
                        <p>Avg Completion Time</p>
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="charts-grid">
                <!-- Monthly Trends -->
                <div class="chart-card">
                    <div class="chart-header">
                        <h3>Monthly Repair Trends</h3>
                        <p>Repairs completed and revenue generated over the last 12 months</p>
                    </div>
                    <div class="chart-container">
                        <canvas id="monthlyTrendsChart"></canvas>
                    </div>
                </div>

                <!-- Status Distribution -->
                <div class="chart-card">
                    <div class="chart-header">
                        <h3>Repair Status Distribution</h3>
                        <p>Current status of all repairs</p>
                    </div>
                    <div class="chart-container">
                        <canvas id="statusChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Reports Tables -->
            <div class="reports-grid">
                <!-- Top Customers -->
                <div class="report-card">
                    <div class="report-header">
                        <h3><i class="fas fa-users"></i>Top Customers</h3>
                    </div>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Customer</th>
                                <th>Repairs</th>
                                <th>Total Spent</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($customer = $top_customers->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?></td>
                                    <td><?php echo $customer['repair_count']; ?></td>
                                    <td><?php echo format_currency($customer['total_spent'] ?: 0); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Recent Repairs -->
                <div class="report-card">
                    <div class="report-header">
                        <h3><i class="fas fa-history"></i>Recent Completed Repairs</h3>
                    </div>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Claim #</th>
                                <th>Customer</th>
                                <th>Vehicle</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($repair = $recent_repairs->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($repair['accident_report_number']); ?></td>
                                    <td><?php echo htmlspecialchars($repair['first_name'] . ' ' . $repair['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($repair['make'] . ' ' . $repair['model']); ?></td>
                                    <td><?php echo format_currency($repair['total_cost'] ?: 0); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Monthly Trends Chart
        const monthlyCtx = document.getElementById('monthlyTrendsChart').getContext('2d');
        new Chart(monthlyCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($monthly_data, 'month')); ?>,
                datasets: [{
                    label: 'Completed Repairs',
                    data: <?php echo json_encode(array_column($monthly_data, 'repairs')); ?>,
                    borderColor: '#fd7e14',
                    backgroundColor: 'rgba(253, 126, 20, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y'
                }, {
                    label: 'Revenue ($)',
                    data: <?php echo json_encode(array_column($monthly_data, 'revenue')); ?>,
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        });

        // Status Distribution Chart
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($status_distribution, 'status')); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_column($status_distribution, 'count')); ?>,
                    backgroundColor: [
                        '#fd7e14',
                        '#ffc107',
                        '#17a2b8',
                        '#28a745',
                        '#dc3545'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        function exportToPDF() {
            alert('PDF export feature would be implemented with a PDF library like jsPDF or server-side PDF generation.');
        }
    </script>
</body>
</html>
